// represent what is sent
export class User {
  email: string;
  name: string;
}
