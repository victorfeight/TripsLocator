// represent what is returned
export class AuthResponse {
  token: string
}
